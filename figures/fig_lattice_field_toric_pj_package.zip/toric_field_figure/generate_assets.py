from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

OUT = Path(__file__).resolve().parent / "assets"
OUT.mkdir(parents=True, exist_ok=True)

# Paper-matched palette.
BLUE = "#1F5A94"
GREEN = "#2E7D4F"
ORANGE = "#D55E00"
PURPLE = "#6A4C93"
DARK = "#263238"
LIGHT = "#D9DEE3"

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 8,
    "axes.linewidth": 0.7,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def save(fig, name: str):
    fig.savefig(OUT / f"{name}.pdf", transparent=True, bbox_inches="tight", pad_inches=0.015)
    fig.savefig(OUT / f"{name}.png", dpi=360, transparent=True, bbox_inches="tight", pad_inches=0.015)
    plt.close(fig)


# -----------------------------------------------------------------------------
# 1) Relative lattice carrying a plane-wave mode.
# -----------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(2.55, 1.82))
coords = np.arange(-5, 6)
for v in coords:
    ax.plot([coords.min(), coords.max()], [v, v], color=LIGHT, lw=0.42, zorder=0)
    ax.plot([v, v], [coords.min(), coords.max()], color=LIGHT, lw=0.42, zorder=0)

xx, yy = np.meshgrid(coords, coords)
kx, ky = 0.73, 0.46
phase = np.cos(kx * xx + ky * yy)
# A restrained blue-orange diverging map consistent with the paper figures.
cmap = LinearSegmentedColormap.from_list("toric_div", [BLUE, "#F6F5F2", ORANGE])
ax.scatter(xx.ravel(), yy.ravel(), c=phase.ravel(), cmap=cmap, vmin=-1, vmax=1,
           s=20, edgecolors="white", linewidths=0.28, zorder=2)

# Central translation axes.
ax.annotate("", xy=(4.7, 0), xytext=(-4.7, 0),
            arrowprops=dict(arrowstyle="->", color=DARK, lw=0.9), zorder=3)
ax.annotate("", xy=(0, 4.7), xytext=(0, -4.7),
            arrowprops=dict(arrowstyle="->", color=DARK, lw=0.9), zorder=3)
# Momentum direction (no text; TikZ supplies labels).
ax.annotate("", xy=(3.25, 2.05), xytext=(0, 0),
            arrowprops=dict(arrowstyle="-|>", color=GREEN, lw=1.25), zorder=4)
ax.set_xlim(-5.35, 5.35)
ax.set_ylim(-5.35, 5.35)
ax.set_aspect("equal")
ax.axis("off")
save(fig, "lattice_mode")


# -----------------------------------------------------------------------------
# 2) Brillouin torus with several J0 momentum centers.
# -----------------------------------------------------------------------------
fig = plt.figure(figsize=(2.65, 1.85))
ax = fig.add_subplot(111, projection="3d")
u = np.linspace(0, 2 * np.pi, 90)
v = np.linspace(0, 2 * np.pi, 44)
U, V = np.meshgrid(u, v)
R, r = 1.45, 0.48
X = (R + r * np.cos(V)) * np.cos(U)
Y = (R + r * np.cos(V)) * np.sin(U)
Z = r * np.sin(V)
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, color="#78C7A3", alpha=0.50,
                linewidth=0.0, antialiased=True, shade=True, rasterized=True)
# A few longitudinal and meridional guide curves.
for vv in [0.0, np.pi/2, np.pi, 3*np.pi/2]:
    x = (R + r * np.cos(vv)) * np.cos(u)
    y = (R + r * np.cos(vv)) * np.sin(u)
    z = np.full_like(u, r * np.sin(vv))
    ax.plot(x, y, z, color="#4C9B78", lw=0.35, alpha=0.45)
for uu in np.linspace(0, 2*np.pi, 10, endpoint=False):
    x = (R + r * np.cos(v)) * np.cos(uu)
    y = (R + r * np.cos(v)) * np.sin(uu)
    z = r * np.sin(v)
    ax.plot(x, y, z, color="#4C9B78", lw=0.30, alpha=0.36)

points = [
    (0.08*np.pi, 0.10*np.pi),
    (0.29*np.pi, -0.16*np.pi),
    (0.54*np.pi, 0.31*np.pi),
    (1.10*np.pi, -0.18*np.pi),
    (1.58*np.pi, 0.18*np.pi),
]
for i, (uu, vv) in enumerate(points):
    x = (R + r * np.cos(vv)) * np.cos(uu)
    y = (R + r * np.cos(vv)) * np.sin(uu)
    z = r * np.sin(vv)
    if i == 1:
        ax.scatter([x], [y], [z], s=46, color=ORANGE, edgecolor="white", linewidth=0.9,
                   depthshade=False, zorder=10)
    else:
        ax.scatter([x], [y], [z], s=26, color=DARK, edgecolor="white", linewidth=0.65,
                   depthshade=False, zorder=9)

ax.view_init(elev=24, azim=-53)
ax.set_box_aspect((2.25, 1.65, 0.82))
ax.set_axis_off()
fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
save(fig, "brillouin_torus")


# -----------------------------------------------------------------------------
# 3) Regularized momentum-space multipoles: J0 / J1 / J2.
# -----------------------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(2.80, 1.03), gridspec_kw={"wspace": 0.08})
grid = np.linspace(-2.6, 2.6, 240)
X, Y = np.meshgrid(grid, grid)
sigma = 0.78
G = np.exp(-(X**2 + Y**2) / (2 * sigma**2))
fields = [G, (X / sigma) * G, (X * Y / sigma**2) * G]
cmaps = [LinearSegmentedColormap.from_list("mono", ["#F7FBFF", "#7DB7D8", BLUE]), "RdBu_r", "RdBu_r"]
for idx, (ax, F, cm) in enumerate(zip(axes, fields, cmaps)):
    if idx == 0:
        ax.contourf(X, Y, F, levels=18, cmap=cm, vmin=0, vmax=1)
    else:
        vmax = np.max(np.abs(F))
        ax.contourf(X, Y, F, levels=np.linspace(-vmax, vmax, 19), cmap=cm, vmin=-vmax, vmax=vmax)
    # Unit circle gives a common local scale around k_0.
    th = np.linspace(0, 2*np.pi, 240)
    ax.plot(1.55*np.cos(th), 1.55*np.sin(th), color=DARK, lw=0.45, ls=(0, (2, 2)), alpha=0.65)
    ax.scatter([0], [0], s=8, color=DARK, zorder=4)
    ax.set_aspect("equal")
    ax.set_xlim(-2.2, 2.2)
    ax.set_ylim(-2.2, 2.2)
    ax.axis("off")
fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
save(fig, "multipoles")


# -----------------------------------------------------------------------------
# 4) A nearby J0 pair approximating a directional jet on a finite window.
# -----------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(2.80, 1.48))
s = np.linspace(-15, 15, 1200)
L = 5.0
eps = 0.12
k0 = 1.05
jet = (s / L) * np.cos(k0 * s)
cluster = (np.sin(eps * s) / (eps * L)) * np.cos(k0 * s)
ax.axvspan(-L, L, color="#E8EDF2", alpha=0.95, zorder=0)
ax.axvline(-L, color="#A8B0B8", lw=0.55, ls=(0, (2, 2)), zorder=1)
ax.axvline(L, color="#A8B0B8", lw=0.55, ls=(0, (2, 2)), zorder=1)
ax.plot(s, jet, color=ORANGE, lw=1.15, zorder=3)
ax.plot(s, cluster, color=GREEN, lw=1.15, ls=(0, (3.2, 2.0)), zorder=4)
ax.axhline(0, color="#70777E", lw=0.45, zorder=1)
ax.set_xlim(-15, 15)
ax.set_ylim(-2.9, 2.9)
ax.set_yticks([])
ax.set_xticks([-L, 0, L])
ax.set_xticklabels([r"$-L$", r"$0$", r"$L$"], fontsize=7)
for side in ["left", "right", "top"]:
    ax.spines[side].set_visible(False)
ax.spines["bottom"].set_linewidth(0.6)
ax.tick_params(axis="x", length=2.0, width=0.55, pad=1)
fig.subplots_adjust(left=0.03, right=0.99, top=0.98, bottom=0.18)
save(fig, "confluence")

print(f"Wrote assets to {OUT}")
