Toric PJ lattice-field figure
==============================

Files
- toric_field_theory_figure.pdf : final standalone figure for inclusion in the paper
- toric_field_theory_figure.tex : TikZ layout source
- generate_assets.py           : Python/Matplotlib source for the four visual assets
- assets/                      : generated PDF and PNG assets
- figure_snippet.tex           : suggested LaTeX figure environment and caption

Build
1. python generate_assets.py
2. latexmk -pdf -interaction=nonstopmode -halt-on-error toric_field_theory_figure.tex

The figure is sized for full text width. Include it with width=\linewidth.
