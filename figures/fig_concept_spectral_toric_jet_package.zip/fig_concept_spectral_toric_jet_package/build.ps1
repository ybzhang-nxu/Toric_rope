$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Script = Join-Path $Root "scripts\make_spectral_toric_jet_assets.py"
$TexDir = Join-Path $Root "tex"
$PdfInTex = Join-Path $TexDir "fig_concept_spectral_toric_jet.pdf"
$PdfOut = Join-Path $Root "fig_concept_spectral_toric_jet.pdf"

python $Script

Push-Location $TexDir
try {
    latexmk -pdf -interaction=nonstopmode -halt-on-error fig_concept_spectral_toric_jet.tex
}
finally {
    Pop-Location
}

Copy-Item -Force $PdfInTex $PdfOut
Write-Host "Built $PdfOut"
