from __future__ import annotations

from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, LightSource
from matplotlib.patches import Rectangle


ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / "assets"
ASSET_DIR.mkdir(parents=True, exist_ok=True)

mpl.rcParams.update(
    {
        "figure.dpi": 220,
        "savefig.dpi": 600,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.linewidth": 0.6,
    }
)

BLUE = "#19559a"
LIGHT_BLUE = "#dce9f8"
INK = "#101828"

GREEN_CMAP = LinearSegmentedColormap.from_list(
    "green_field",
    ["#f8fffb", "#d8eee6", "#8bc7b8", "#28733d"],
    N=256,
)


def save_2d(fig: plt.Figure, stem: str) -> None:
    for ext in ("pdf", "svg"):
        fig.savefig(
            ASSET_DIR / f"{stem}.{ext}",
            bbox_inches="tight",
            pad_inches=0.01,
            transparent=True,
        )
    plt.close(fig)


def draw_relative_lattice_window() -> None:
    fig, ax = plt.subplots(figsize=(3.2, 4.95))
    ax.set_xlim(-5.4, 5.4)
    ax.set_ylim(-6.0, 5.5)
    ax.set_aspect("equal")
    ax.axis("off")

    grid_color = "#8b8f96"
    for g in range(-5, 6):
        ax.plot([-5.0, 5.0], [g, g], color=grid_color, lw=0.55, alpha=0.58, zorder=0)
        ax.plot([g, g], [-5.0, 5.0], color=grid_color, lw=0.55, alpha=0.58, zorder=0)

    xs, ys = np.meshgrid(np.arange(-5, 6), np.arange(-5, 6))
    ax.scatter(xs.ravel(), ys.ravel(), s=11, color="#80848a", alpha=0.86, zorder=1)

    ax.add_patch(
        Rectangle(
            (-3.35, -3.35),
            6.70,
            6.70,
            facecolor=LIGHT_BLUE,
            edgecolor=BLUE,
            lw=1.05,
            ls=(0, (4, 2)),
            alpha=0.26,
            zorder=2,
        )
    )

    ax.annotate(
        "",
        xy=(5.2, 0),
        xytext=(-5.2, 0),
        arrowprops=dict(arrowstyle="-|>", lw=1.05, color=INK, mutation_scale=9),
        zorder=3,
    )
    ax.annotate(
        "",
        xy=(0, 5.2),
        xytext=(0, -5.8),
        arrowprops=dict(arrowstyle="-|>", lw=1.05, color=INK, mutation_scale=9),
        zorder=3,
    )
    ax.scatter([0], [0], s=18, color=INK, zorder=4)

    ax.annotate(
        "",
        xy=(2.9, 0),
        xytext=(0, 0),
        arrowprops=dict(arrowstyle="-|>", lw=1.5, color=BLUE, mutation_scale=14),
        zorder=5,
    )
    ax.annotate(
        "",
        xy=(0, 3.0),
        xytext=(0, 0),
        arrowprops=dict(arrowstyle="-|>", lw=1.5, color=BLUE, mutation_scale=14),
        zorder=5,
    )

    save_2d(fig, "relative_lattice_window")


def surface_colors(z: np.ndarray) -> np.ndarray:
    light = LightSource(azdeg=315, altdeg=42)
    return light.shade(z, cmap=GREEN_CMAP, vert_exag=0.55, blend_mode="soft")


def draw_spectral_torus_green() -> None:
    u = np.linspace(0, 2 * np.pi, 190)
    v = np.linspace(0, 2 * np.pi, 86)
    uu, vv = np.meshgrid(u, v)
    major, minor = 2.28, 0.64
    x = (major + minor * np.cos(vv)) * np.cos(uu)
    y = (major + minor * np.cos(vv)) * np.sin(uu)
    z = minor * np.sin(vv)
    color_field = 0.40 * np.cos(uu - 0.35) + 0.35 * np.sin(vv) + 0.20 * np.cos(2.0 * uu)

    fig = plt.figure(figsize=(3.85, 3.00))
    ax = fig.add_axes([0, 0, 1, 1], projection="3d")
    ax.plot_surface(
        x,
        y,
        z,
        rstride=2,
        cstride=2,
        facecolors=surface_colors(color_field),
        linewidth=0.23,
        edgecolor=(0.03, 0.28, 0.22, 0.20),
        antialiased=True,
        shade=False,
    )
    ax.view_init(elev=25, azim=-48)
    ax.set_box_aspect((1.34, 1.0, 0.42))
    ax.set_xlim(-3.0, 3.0)
    ax.set_ylim(-3.0, 3.0)
    ax.set_zlim(-0.82, 0.82)
    ax.set_axis_off()
    fig.savefig(
        ASSET_DIR / "spectral_torus_green.png",
        bbox_inches="tight",
        pad_inches=0.0,
        transparent=True,
        dpi=600,
    )
    plt.close(fig)


def main() -> None:
    draw_relative_lattice_window()
    draw_spectral_torus_green()


if __name__ == "__main__":
    main()
