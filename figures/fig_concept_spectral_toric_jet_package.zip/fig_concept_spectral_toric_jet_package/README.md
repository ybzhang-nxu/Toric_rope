# fig_concept_spectral_toric_jet

Reproducible source package for `fig_concept_spectral_toric_jet`.

## Contents

- `scripts/make_spectral_toric_jet_assets.py`: Python/Matplotlib asset generator.
- `assets/relative_lattice_window.pdf`: vector lattice/window asset used by TikZ.
- `assets/relative_lattice_window.svg`: SVG copy of the lattice/window asset.
- `assets/spectral_torus_green.png`: 600 dpi transparent torus raster asset.
- `tex/concept_style.tex`: shared TikZ/LaTeX style definitions.
- `tex/fig_concept_spectral_toric_jet.tex`: standalone TikZ composition.
- `fig_concept_spectral_toric_jet.pdf`: compiled final PDF.

## Build

From this package directory:

```powershell
pip install -r requirements.txt
.\build.ps1
```

Manual equivalent:

```powershell
python scripts\make_spectral_toric_jet_assets.py
cd tex
latexmk -pdf -interaction=nonstopmode -halt-on-error fig_concept_spectral_toric_jet.tex
```

The Python step regenerates the image/geometry assets. The TikZ step lays out
the panels, labels, formulas, arrows, and final typography.
